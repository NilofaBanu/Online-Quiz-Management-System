<?php 
session_start(); 
include('includes/header.php'); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Question Master</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <main>
        <section class="hero-section">
            <div class="container">
                <h2>Welcome to Question Master</h2>
                <p>Your ultimate quiz platform for taking and managing quizzes.</p>
                <a href="/question_master/pages/take_quiz.php" class="btn btn-light">Start a Quiz</a>
            </div>
        </section>

        <section class="features text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card feature-card">
                            <div class="card-body feature-card-body">
                                <h5 class="card-title">Take Quizzes</h5>
                                <p class="card-text">Choose from a variety of quizzes and test your knowledge.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card feature-card">
                            <div class="card-body feature-card-body">
                                <h5 class="card-title">Add Questions</h5>
                                <p class="card-text">Admin users can add new questions to the quiz database.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card feature-card">
                            <div class="card-body feature-card-body">
                                <h5 class="card-title">Manage Quizzes</h5>
                                <p class="card-text">Organize and manage quizzes efficiently from the admin panel.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php include('includes/footer.php'); ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
