<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question Master</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/question_master/assets/css/style.css">

    <!-- Confetti.js -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
</head>
<body>
    <header class="bg-dark text-white p-3">
        <div class="container">
            <h1 class="text-center">Question Master</h1>
            <nav class="navbar navbar-expand-lg navbar-dark">
                <div class="container-fluid">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="/question_master/index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/question_master/pages/take_quiz.php">Take Quiz</a>
                        </li>
                        <?php if (isset($_SESSION['username'])): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="/question_master/pages/create_quiz.php">Create Quiz</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/question_master/pages/manage_quizzes.php">Manage Quizzes</a>
                            </li>
                            <?php if ($_SESSION['role'] == 'admin'): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="/question_master/pages/add_question.php">Add Question</a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                    <ul class="navbar-nav ms-auto">
                        <?php if (isset($_SESSION['username'])): ?>
                            <li class="nav-item">
                                <span class="nav-link">Hello, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/question_master/pages/logout.php">Logout</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="/question_master/pages/login.php">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/question_master/pages/register.php">Register</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const resultAlert = document.querySelector('.alert-success');
        if (resultAlert) {
            const percentage = parseFloat(resultAlert.getAttribute('data-percentage'));

            const resultContainer = document.querySelector('#result-container');
            if (percentage >= 80) {
                // High score
                resultContainer.classList.add('bg-success', 'text-white');
                resultAlert.classList.add('animate__animated', 'animate__fadeIn', 'animate__rubberBand');
                confetti({
                    particleCount: 200,
                    spread: 60,
                    origin: { y: 0.6 }
                });
            } else if (percentage >= 50) {
                // Medium score
                resultContainer.classList.add('bg-warning', 'text-dark');
                resultAlert.classList.add('animate__animated', 'animate__fadeInUp');
            } else {
                // Low score
                resultContainer.classList.add('bg-danger', 'text-white');
                resultAlert.classList.add('animate__animated', 'animate__fadeInDown', 'animate__heartBeat');
            }
        }
    });
    </script>


    <main>
        <!-- Page content will go here -->
    </main>
</body>
</html>
