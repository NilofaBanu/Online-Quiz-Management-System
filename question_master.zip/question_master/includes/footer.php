<footer class="footer bg-dark text-white py-3 fixed-bottom">
    <div class="container text-center">
        <p class="mb-0">&copy; 2024 Question Master. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
