<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM questions WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $question = $result->fetch_assoc();

    // Fetch quizzes
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE user_id = ?");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $quizzes = $result->fetch_all(MYSQLI_ASSOC);
}

// Handle form submission for updating
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['id'];
    $question_text = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_option = (int)$_POST['correct_option'];
    $quiz_id = (int)$_POST['quiz_id'];

    $stmt = $conn->prepare("UPDATE questions SET question = ?, option1 = ?, option2 = ?, option3 = ?, option4 = ?, correct_option = ?, quiz_id = ? WHERE id = ?");
    $stmt->bind_param('sssssiii', $question_text, $option1, $option2, $option3, $option4, $correct_option, $quiz_id, $id);
    $stmt->execute();

    echo '<div class="alert alert-success">Question updated successfully!</div>';
    header("Location: manage_questions.php?quiz_id=" . urlencode($quiz_id));
    exit();
}
?>

<div class="container mt-5">
    <h2>Edit Question</h2>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($question['id']); ?>">
        <div class="mb-3">
            <label for="quiz_id" class="form-label">Select Quiz:</label>
            <select name="quiz_id" class="form-select" required>
                <?php foreach ($quizzes as $quiz): ?>
                    <option value="<?php echo htmlspecialchars($quiz['id']); ?>" <?php echo $question['quiz_id'] == $quiz['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($quiz['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="question" class="form-label">Question:</label>
            <input type="text" name="question" class="form-control" value="<?php echo htmlspecialchars($question['question']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="option1" class="form-label">Option 1:</label>
            <input type="text" name="option1" class="form-control" value="<?php echo htmlspecialchars($question['option1']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="option2" class="form-label">Option 2:</label>
            <input type="text" name="option2" class="form-control" value="<?php echo htmlspecialchars($question['option2']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="option3" class="form-label">Option 3:</label>
            <input type="text" name="option3" class="form-control" value="<?php echo htmlspecialchars($question['option3']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="option4" class="form-label">Option 4:</label>
            <input type="text" name="option4" class="form-control" value="<?php echo htmlspecialchars($question['option4']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="correct_option" class="form-label">Correct Option:</label>
            <select name="correct_option" class="form-select" required>
                <option value="1" <?php echo $question['correct_option'] == 1 ? 'selected' : ''; ?>>Option 1</option>
                <option value="2" <?php echo $question['correct_option'] == 2 ? 'selected' : ''; ?>>Option 2</option>
                <option value="3" <?php echo $question['correct_option'] == 3 ? 'selected' : ''; ?>>Option 3</option>
                <option value="4" <?php echo $question['correct_option'] == 4 ? 'selected' : ''; ?>>Option 4</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update Question</button>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
