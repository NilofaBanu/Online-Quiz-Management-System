<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo '
    <div class="container mt-5">
        <div class="alert alert-warning d-flex align-items-center" role="alert">
            <div>
                <strong>Access Denied</strong> - You need to be logged in to take quizzes. Please <a href="register.php" class="btn btn-secondary btn-sm">Create an Account</a> or <a href="login.php" class="btn btn-primary btn-sm ms-2">Login</a>.
            </div>
        </div>
    </div>';
    include('../includes/footer.php');
    exit();
}

// Fetch quizzes
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM quizzes WHERE is_public = 1 OR user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$quizzes = $result->fetch_all(MYSQLI_ASSOC);
?>

<div class="container mt-5">
    <h2>Available Quizzes</h2>
    <?php if (empty($quizzes)): ?>
        <div class="alert alert-info" role="alert">
            <strong>No Quizzes Available</strong> - There are no quizzes available at the moment. Please check back later or <a href="create_quiz.php" class="btn btn-primary btn-sm">Create a Quiz</a> to add new quizzes.
        </div>
    <?php else: ?>
        <div class="list-group">
            <?php foreach ($quizzes as $quiz): ?>
                <a href="quiz.php?id=<?php echo $quiz['id']; ?>" class="list-group-item list-group-item-action">
                    <h5><?php echo htmlspecialchars($quiz['title']); ?></h5>
                    <p><?php echo htmlspecialchars($quiz['description']); ?></p>
                    <small><?php echo $quiz['is_public'] ? 'Public' : 'Private'; ?></small>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>
