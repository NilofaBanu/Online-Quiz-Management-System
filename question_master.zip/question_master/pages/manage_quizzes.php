<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

$user_id = $_SESSION['user_id'];

// Fetch quizzes for the logged-in user
$query = "SELECT * FROM quizzes WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$quizzes = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
?>

<div class="container mt-5">
    <h2>Manage Your Quizzes</h2>
    <a href="create_quiz.php" class="btn btn-primary mb-3">Create New Quiz</a>

    <?php if ($quizzes): ?>
        <div class="row">
            <?php foreach ($quizzes as $quiz): ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($quiz['title']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($quiz['description']); ?></p>
                            <a href="edit_quiz.php?id=<?php echo htmlspecialchars($quiz['id']); ?>" class="btn btn-secondary btn-sm">Edit Quiz</a>
                            <a href="delete_quiz.php?id=<?php echo htmlspecialchars($quiz['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirmDeletion();">Delete Quiz</a>
                            <a href="manage_questions.php?quiz_id=<?php echo htmlspecialchars($quiz['id']); ?>" class="btn btn-primary btn-sm">Manage Questions</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">You have not created any quizzes yet.</div>
    <?php endif; ?>
</div>

<script>
function confirmDeletion() {
    return confirm('Are you sure you want to delete this quiz? This action cannot be undone.');
}
</script>

<?php include('../includes/footer.php'); ?>
