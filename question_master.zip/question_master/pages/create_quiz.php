<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $is_public = isset($_POST['is_public']) ? 1 : 0;
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO quizzes (user_id, title, description, is_public) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('issi', $user_id, $title, $description, $is_public);

    if ($stmt->execute()) {
        echo '<div class="alert alert-success">Quiz created successfully!</div>';
    } else {
        echo '<div class="alert alert-danger">Failed to create quiz.</div>';
    }
    header("Location: manage_quizzes.php");
    exit();
}
?>

<div class="container mt-5">
    <h2>Create New Quiz</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="title" class="form-label">Title:</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description:</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
        <div class="mb-3">
            <label for="is_public" class="form-check-label">Make Public:</label>
            <input type="checkbox" name="is_public" class="form-check-input">
        </div>
        <button type="submit" class="btn btn-primary">Create Quiz</button>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
