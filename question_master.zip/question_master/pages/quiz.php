<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (isset($_GET['id'])) {
    $quiz_id = (int)$_GET['id'];

    // Fetch quiz details
    $stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ?");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $quiz = $result->fetch_assoc();

    if (!$quiz) {
        echo '<div class="container mt-5"><div class="alert alert-danger">Quiz not found.</div></div>';
        include('../includes/footer.php');
        exit();
    }

    // Fetch questions for this quiz
    $stmt = $conn->prepare("SELECT * FROM questions WHERE quiz_id = ? ORDER BY RAND()");
    $stmt->bind_param("i", $quiz_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $questions = $result->fetch_all(MYSQLI_ASSOC);
    $total = count($questions);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $score = 0;
        $feedback = [];

        foreach ($_POST['answers'] as $question_id => $answer) {
            $stmt = $conn->prepare("SELECT correct_option FROM questions WHERE id = ?");
            $stmt->bind_param("i", $question_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $correct_option = $result->fetch_assoc()['correct_option'];

            if ((int)$answer === (int)$correct_option) {
                $score++;
                $feedback[$question_id] = 'correct';
            } else {
                $feedback[$question_id] = 'incorrect';
            }
        }

        $percentage = round(($score / $total) * 100);
        echo "<div id='result-container' class='container mt-5'>
                <div class='alert alert-success' data-percentage='$percentage'>You scored $score out of $total ($percentage%)</div>
              </div>";
    }

} else {
    echo '<div class="container mt-5"><div class="alert alert-danger">No quiz ID provided.</div></div>';
    include('../includes/footer.php');
    exit();
}
?>

<div class="container mt-5 mb-5">
    <h2><?php echo htmlspecialchars($quiz['title']); ?></h2>
    <p><?php echo htmlspecialchars($quiz['description']); ?></p>

    <?php if ($quiz['is_public'] || $_SESSION['user_id'] == $quiz['user_id']): ?>
        <?php if ($total > 0): ?>
            <h3>Questions</h3>
            <form method="POST" action="">
                <?php foreach ($questions as $index => $question): ?>
                    <?php
                    $feedback_class = '';
                    $feedback_message = '';

                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        $user_answer = $_POST['answers'][$question['id']] ?? null;

                        if (isset($feedback[$question['id']])) {
                            if ($feedback[$question['id']] === 'correct') {
                                $feedback_class = 'border-success';
                                $feedback_message = '<div class="text-success">Correct!</div>';
                            } else {
                                $feedback_class = 'border-danger';
                                $feedback_message = '<div class="text-danger">Incorrect! Correct Answer: ' . htmlspecialchars($question['option' . $question['correct_option']]) . '</div>';
                            }
                        }
                    }
                    ?>

                    <div class="card mb-4 <?php echo $feedback_class; ?>">
                        <div class="card-body">
                            <h5 class="card-title">Question <?php echo $index + 1; ?>: <?php echo htmlspecialchars($question['question']); ?></h5>

                            <!-- Options with visual feedback -->
                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                <div class="form-check <?php echo (isset($user_answer) && $user_answer == $i) ? (($feedback[$question['id']] == 'correct') ? 'text-success' : 'text-danger') : ''; ?>">
                                    <input type="radio" name="answers[<?php echo $question['id']; ?>]" value="<?php echo $i; ?>" class="form-check-input" <?php echo (isset($user_answer) && $user_answer == $i) ? 'checked' : ''; ?> required>
                                    <label class="form-check-label"><?php echo htmlspecialchars($question['option' . $i]); ?></label>
                                </div>
                            <?php endfor; ?>

                            <!-- Show feedback message -->
                            <?php echo $feedback_message; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="btn btn-success mb-5">Submit Quiz</button>
            </form>
        <?php else: ?>
            <div class="alert alert-info">No questions available for this quiz.</div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-info">This quiz is private.</div>
    <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>
