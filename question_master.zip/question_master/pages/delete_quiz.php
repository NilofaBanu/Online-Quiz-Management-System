<?php
session_start();
include('../includes/db.php');

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-danger">You need to log in to delete quizzes.</div>';
    exit();
}

if (!isset($_GET['id'])) {
    echo '<div class="alert alert-danger">No quiz ID provided.</div>';
    exit();
}

$id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Check if quiz belongs to the logged-in user
$stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ? AND user_id = ?");
$stmt->bind_param('ii', $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$quiz = $result->fetch_assoc();

if (!$quiz) {
    echo '<div class="alert alert-danger">Quiz not found or access denied.</div>';
    exit();
}

// Begin a transaction
$conn->begin_transaction();

try {
    // Delete all questions related to the quiz
    $stmt = $conn->prepare("DELETE FROM questions WHERE quiz_id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Delete the quiz
    $stmt = $conn->prepare("DELETE FROM quizzes WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();

    // Commit the transaction
    $conn->commit();

    echo '<div class="alert alert-success">Quiz deleted successfully!</div>';
    header("Location: manage_quizzes.php");
    exit();
} catch (Exception $e) {
    // Rollback the transaction if something fails
    $conn->rollback();
    echo '<div class="alert alert-danger">Failed to delete quiz. Please try again.</div>';
}
?>
