<?php
session_start();
include('../includes/db.php');

if (isset($_GET['id'])) {
    $id = (int)$_GET['id']; 

    // Delete the question from the database
    $stmt = $conn->prepare("DELETE FROM questions WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();

    // Redirect to the question management page
    header("Location: manage_questions.php?quiz_id=" . urlencode($_GET['quiz_id']));
    exit();
}
?>
