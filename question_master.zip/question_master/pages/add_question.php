<?php
session_start();
include('../includes/db.php'); 
include('../includes/header.php');

// Fetch quizzes
$stmt = $conn->prepare("SELECT * FROM quizzes WHERE user_id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$quizzes = $result->fetch_all(MYSQLI_ASSOC);

$selected_quiz_id = isset($_GET['quiz_id']) ? $_GET['quiz_id'] : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_option = $_POST['correct_option'];
    $quiz_id = $_POST['quiz_id'];

    $stmt = $conn->prepare("INSERT INTO questions (question, option1, option2, option3, option4, correct_option, quiz_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('ssssssi', $question, $option1, $option2, $option3, $option4, $correct_option, $quiz_id);
    $stmt->execute();

    echo '<div class="alert alert-success">Question added successfully!</div>';
}
?>

<div class="container mt-5">
    <h2>Add New Question</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="quiz_id" class="form-label">Select Quiz:</label>
            <select name="quiz_id" class="form-select" required>
                <?php foreach ($quizzes as $quiz): ?>
                    <option value="<?php echo htmlspecialchars($quiz['id']); ?>" <?php echo $quiz['id'] == $selected_quiz_id ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($quiz['title']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="question" class="form-label">Question:</label>
            <input type="text" name="question" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="option1" class="form-label">Option 1:</label>
            <input type="text" name="option1" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="option2" class="form-label">Option 2:</label>
            <input type="text" name="option2" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="option3" class="form-label">Option 3:</label>
            <input type="text" name="option3" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="option4" class="form-label">Option 4:</label>
            <input type="text" name="option4" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="correct_option" class="form-label">Correct Option:</label>
            <select name="correct_option" class="form-select" required>
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Add Question</button>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
