<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

$quiz_id = $_GET['quiz_id'];

// Fetch all questions for this quiz
$query = "SELECT * FROM questions WHERE quiz_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $quiz_id);
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
?>

<div class="container mt-5">
    <h2 class="mb-4">Manage Questions for Quiz</h2>

    <a href="add_question.php?quiz_id=<?php echo htmlspecialchars($quiz_id); ?>" class="btn btn-primary mb-4">Add New Question</a>

    <?php if ($questions): ?>
        <div class="list-group">
            <?php foreach ($questions as $index => $question): ?>
                <div class="list-group-item mb-3 border rounded shadow-sm">
                    <h5 class="mb-3">Question <?php echo $index + 1; ?>: <?php echo htmlspecialchars($question['question']); ?></h5>
                    <ul class="list-group mb-3">
                        <li class="list-group-item <?php echo $question['correct_option'] == 1 ? 'list-group-item-success' : ''; ?>">Option 1: <?php echo htmlspecialchars($question['option1']); ?></li>
                        <li class="list-group-item <?php echo $question['correct_option'] == 2 ? 'list-group-item-success' : ''; ?>">Option 2: <?php echo htmlspecialchars($question['option2']); ?></li>
                        <li class="list-group-item <?php echo $question['correct_option'] == 3 ? 'list-group-item-success' : ''; ?>">Option 3: <?php echo htmlspecialchars($question['option3']); ?></li>
                        <li class="list-group-item <?php echo $question['correct_option'] == 4 ? 'list-group-item-success' : ''; ?>">Option 4: <?php echo htmlspecialchars($question['option4']); ?></li>
                    </ul>
                    <div class="d-flex justify-content-start">
                        <a href="edit_question.php?id=<?php echo htmlspecialchars($question['id']); ?>&quiz_id=<?php echo htmlspecialchars($quiz_id); ?>" class="btn btn-secondary btn-sm me-2">Edit</a>
                        <a href="delete_question.php?id=<?php echo htmlspecialchars($question['id']); ?>&quiz_id=<?php echo htmlspecialchars($quiz_id); ?>" class="btn btn-danger btn-sm" onclick="return confirmDeletion();">Delete</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">No questions found for this quiz.</div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- delete confirmation -->
<script>
function confirmDeletion() {
    return confirm('Are you sure you want to delete this question? This action cannot be undone.');
}
</script>

<?php include('../includes/footer.php'); ?>
