<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (!isset($_GET['id'])) {
    echo 'No quiz ID provided.';
    exit();
}

$id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch quiz details
$stmt = $conn->prepare("SELECT * FROM quizzes WHERE id = ? AND user_id = ?");
$stmt->bind_param('ii', $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$quiz = $result->fetch_assoc();

if (!$quiz) {
    echo 'Quiz not found or access denied.';
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $is_public = isset($_POST['is_public']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE quizzes SET title = ?, description = ?, is_public = ? WHERE id = ?");
    $stmt->bind_param('ssii', $title, $description, $is_public, $id);
    
    if ($stmt->execute()) {
        echo '<div class="alert alert-success">Quiz updated successfully!</div>';
        header("Location: manage_quizzes.php");
        exit();
    } else {
        echo '<div class="alert alert-danger">Failed to update quiz.</div>';
    }
}
?>

<div class="container mt-5">
    <h2>Edit Quiz</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="title" class="form-label">Title:</label>
            <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($quiz['title']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description:</label>
            <textarea name="description" class="form-control"><?php echo htmlspecialchars($quiz['description']); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="is_public" class="form-check-label">Make Public:</label>
            <input type="checkbox" name="is_public" class="form-check-input" <?php if ($quiz['is_public']) echo 'checked'; ?>>
        </div>
        <button type="submit" class="btn btn-primary">Update Quiz</button>
    </form>
</div>

<?php include('../includes/footer.php'); ?>
